package com.epimorphics.lda.exceptions;

public class GeneralException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
