package com.epimorphics.lda.exceptions;

public class VelocityRenderingException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}