/*
    See lda-top/LICENCE (or https://raw.github.com/epimorphics/elda/master/LICENCE)
    for the licence for this software.
    
    (c) Copyright 2011, 2014 Epimorphics Limited
    $Id$
*/

package com.epimorphics.lda.vocabularies;

/**
   Deprecated. Use ELDA_API (for API + Elda extensions) or plain API
   (for LDA-defined properties).
   
   @deprecated
*/
public class EXTRAS extends ELDA_API {
	
}
