/*
    See lda-top/LICENCE (or https://raw.github.com/epimorphics/elda/master/LICENCE)
    for the licence for this software.
    
    (c) Copyright 2011 Epimorphics Limited
    $Id$
*/

package com.epimorphics.lda.tests_support;

import com.hp.hpl.jena.shared.JenaException;

public class NotImplementedException extends JenaException
	{
	private static final long serialVersionUID = 1L;
	}